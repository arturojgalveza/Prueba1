package com.danielme.demo.springdatajpa.repository;


public interface CountryRepositoryCustom 
{	
	void clearEntityCache();	
}
