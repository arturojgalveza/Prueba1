package com.danielme.demo.springdatajpa;

public class AuthenticationMockup
{

	public static String UserName;
}
